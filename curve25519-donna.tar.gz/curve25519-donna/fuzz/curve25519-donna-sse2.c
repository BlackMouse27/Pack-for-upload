#define CURVE25519_SSE2
#define CURVE25519_SUFFIX _sse2
#include "../curve25519.c"
